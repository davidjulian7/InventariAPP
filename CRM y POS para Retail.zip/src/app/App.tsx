import { useState, useRef, useEffect } from "react";
import {
  LayoutDashboard, ShoppingCart, Package, BarChart3, Bot,
  Settings, HelpCircle, Search, Bell, TrendingUp, TrendingDown,
  AlertTriangle, Plus, Scan, CreditCard, Banknote, Smartphone,
  Mail, MessageCircle, Download, Filter, Eye, Edit2,
  Trash2, CheckCircle, XCircle, ArrowUpRight, Send,
  Sparkles, FileText, Users, Building2, ChevronDown, ChevronRight,
  Package2, ShoppingBag, LogOut, X, Star, RefreshCw, Zap,
  DollarSign, ShoppingBasket, Tag, MessageSquare, BookOpen,
  Phone, LifeBuoy, Printer, Menu, PanelLeftClose, PanelLeftOpen
} from "lucide-react";
import {
  AreaChart, Area, BarChart, Bar, LineChart, Line,
  PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid,
  Tooltip, ResponsiveContainer
} from "recharts";

// ── Breakpoint Hook ────────────────────────────────────────────────────────
function useBreakpoint() {
  const getW = () => (typeof window !== "undefined" ? window.innerWidth : 1280);
  const [w, setW] = useState(getW);
  useEffect(() => {
    const h = () => setW(window.innerWidth);
    window.addEventListener("resize", h);
    return () => window.removeEventListener("resize", h);
  }, []);
  return { isMobile: w < 768, isTablet: w >= 768 && w < 1024, isDesktop: w >= 1024, width: w };
}

// ── Mock Data ──────────────────────────────────────────────────────────────
const salesChartData = [
  { dia: "Lun", ventas: 8420, ganancia: 2100 },
  { dia: "Mar", ventas: 12340, ganancia: 3085 },
  { dia: "Mié", ventas: 9870, ganancia: 2468 },
  { dia: "Jue", ventas: 15200, ganancia: 3800 },
  { dia: "Vie", ventas: 18900, ganancia: 4725 },
  { dia: "Sáb", ventas: 22100, ganancia: 5525 },
  { dia: "Dom", ventas: 14320, ganancia: 3580 },
];
const monthlyData = [
  { mes: "Ene", ventas: 280000 }, { mes: "Feb", ventas: 310000 },
  { mes: "Mar", ventas: 295000 }, { mes: "Abr", ventas: 342000 },
  { mes: "May", ventas: 380000 }, { mes: "Jun", ventas: 342800 },
];
const topProducts = [
  { nombre: "Leche Lala 1L", ventas: 342, ingresos: 8208, margen: 18 },
  { nombre: "Agua Ciel 600ml", ventas: 289, ingresos: 3468, margen: 24 },
  { nombre: "Coca-Cola 600ml", ventas: 267, ingresos: 5340, margen: 22 },
  { nombre: "Pan Bimbo", ventas: 198, ingresos: 4356, margen: 20 },
  { nombre: "Sabritas Original", ventas: 187, ingresos: 2805, margen: 28 },
];
const categoryData = [
  { name: "Bebidas", value: 35, color: "#628141" },
  { name: "Lácteos", value: 22, color: "#8BAE66" },
  { name: "Botanas", value: 18, color: "#EBD5AB" },
  { name: "Abarrotes", value: 15, color: "#3D5428" },
  { name: "Limpieza", value: 10, color: "#C4A87A" },
];
const inventoryProducts = [
  { id: 1, sku: "BEB-001", nombre: "Coca-Cola 600ml", categoria: "Bebidas", precio_compra: 12.50, precio_venta: 20.00, existencia: 48, stock_min: 20, margen: 37.5, estado: "ok" },
  { id: 2, sku: "LAC-002", nombre: "Leche Lala 1L", categoria: "Lácteos", precio_compra: 19.00, precio_venta: 24.00, existencia: 12, stock_min: 15, margen: 20.8, estado: "bajo" },
  { id: 3, sku: "BOT-003", nombre: "Sabritas Original 45g", categoria: "Botanas", precio_compra: 10.50, precio_venta: 15.00, existencia: 0, stock_min: 10, margen: 30.0, estado: "agotado" },
  { id: 4, sku: "BEB-004", nombre: "Agua Ciel 600ml", categoria: "Bebidas", precio_compra: 9.00, precio_venta: 12.00, existencia: 72, stock_min: 30, margen: 25.0, estado: "ok" },
  { id: 5, sku: "ABR-005", nombre: "Arroz La Merced 1kg", categoria: "Abarrotes", precio_compra: 22.00, precio_venta: 30.00, existencia: 8, stock_min: 12, margen: 26.7, estado: "bajo" },
  { id: 6, sku: "LAC-006", nombre: "Queso Oaxaca 400g", categoria: "Lácteos", precio_compra: 45.00, precio_venta: 65.00, existencia: 15, stock_min: 10, margen: 30.8, estado: "ok" },
  { id: 7, sku: "LIM-007", nombre: "Detergente Ariel 1kg", categoria: "Limpieza", precio_compra: 55.00, precio_venta: 75.00, existencia: 3, stock_min: 8, margen: 26.7, estado: "bajo" },
  { id: 8, sku: "BEB-008", nombre: "Jugo del Valle 1L", categoria: "Bebidas", precio_compra: 18.00, precio_venta: 25.00, existencia: 34, stock_min: 20, margen: 28.0, estado: "ok" },
];
const recentSales = [
  { id: "#V-1047", cliente: "Cliente general", total: 127.50, metodo: "Efectivo", hora: "14:23" },
  { id: "#V-1046", cliente: "María González", total: 345.00, metodo: "Transferencia", hora: "13:45" },
  { id: "#V-1045", cliente: "Cliente general", total: 89.00, metodo: "Efectivo", hora: "13:12" },
  { id: "#V-1044", cliente: "Restaurante El Sol", total: 1240.00, metodo: "Terminal", hora: "12:30" },
  { id: "#V-1043", cliente: "Cliente general", total: 56.50, metodo: "Efectivo", hora: "11:58" },
];
const posProducts = [
  { id: 1, codigo: "7501055300231", nombre: "Coca-Cola 600ml", precio: 20.00, categoria: "Bebidas" },
  { id: 2, codigo: "7500478000014", nombre: "Leche Lala 1L", precio: 24.00, categoria: "Lácteos" },
  { id: 3, codigo: "7501011008084", nombre: "Sabritas Original", precio: 15.00, categoria: "Botanas" },
  { id: 4, codigo: "7501055328037", nombre: "Agua Ciel 600ml", precio: 12.00, categoria: "Bebidas" },
  { id: 5, codigo: "7500462010012", nombre: "Pan Bimbo", precio: 22.00, categoria: "Panadería" },
  { id: 6, codigo: "7501023011014", nombre: "Arroz La Merced 1kg", precio: 30.00, categoria: "Abarrotes" },
  { id: 7, codigo: "7501031305059", nombre: "Frijol Bayo 1kg", precio: 28.00, categoria: "Abarrotes" },
  { id: 8, codigo: "7501003020024", nombre: "Aceite Nutrioli 900ml", precio: 52.00, categoria: "Abarrotes" },
];
const initAiMessages = [
  { role: "assistant", content: "Hola! Soy tu asistente IA. Puedo analizar ventas, detectar tendencias, alertarte sobre el inventario y darte recomendaciones. En que te ayudo?" },
  { role: "user", content: "Cuanto vendi hoy?" },
  { role: "assistant", content: "Ventas del dia:\n\nHoy generaste $12,450 con 67 transacciones. Ticket promedio $185.82.\n\nEsto es +8.3% vs el lunes pasado. Mejor hora: 1pm-2pm con $2,340." },
  { role: "user", content: "Que debo reabastecer urgentemente?" },
  { role: "assistant", content: "Reabastecimiento urgente:\n\nAgotados: Sabritas Original 45g - 0 uds.\n\nStock bajo:\n- Leche Lala 1L - 12 uds. (min. 15)\n- Arroz La Merced - 8 uds. (min. 12)\n- Detergente Ariel - 3 uds. (min. 8)\n\nLa Leche Lala es prioridad alta por su alta rotacion." },
];
const aiInsights = [
  { titulo: "Ventas al alza", desc: "+8.3% vs semana anterior", icon: TrendingUp, color: "text-green-600" },
  { titulo: "4 en riesgo", desc: "Requieren reabastecimiento", icon: AlertTriangle, color: "text-amber-600" },
  { titulo: "Bebidas lideran", desc: "35% del total de ventas", icon: Star, color: "text-primary" },
  { titulo: "Proyeccion mes", desc: "$380,000 estimado", icon: Zap, color: "text-blue-600" },
];

// ── Shared UI ──────────────────────────────────────────────────────────────
type BadgeVariant = "default" | "success" | "warning" | "danger" | "info";
function Badge({ children, variant = "default" }: { children: React.ReactNode; variant?: BadgeVariant }) {
  const v: Record<BadgeVariant, string> = {
    default: "bg-muted text-muted-foreground",
    success: "bg-green-100 text-green-700",
    warning: "bg-amber-100 text-amber-700",
    danger: "bg-red-100 text-red-700",
    info: "bg-blue-100 text-blue-700",
  };
  return <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${v[variant]}`}>{children}</span>;
}

type BtnVariant = "primary" | "secondary" | "ghost" | "outline" | "danger" | "accent";
function Btn({ children, variant = "primary", size = "md", onClick, className = "", disabled = false }: {
  children: React.ReactNode; variant?: BtnVariant; size?: "sm" | "md" | "lg";
  onClick?: () => void; className?: string; disabled?: boolean;
}) {
  const s = { sm: "px-3 py-2 text-xs rounded-xl", md: "px-4 py-2.5 text-sm rounded-xl", lg: "px-6 py-3 text-base rounded-2xl" };
  const v: Record<BtnVariant, string> = {
    primary: "bg-primary text-primary-foreground hover:bg-secondary active:scale-[0.98]",
    secondary: "bg-secondary/20 text-primary hover:bg-secondary/30",
    ghost: "text-muted-foreground hover:bg-muted hover:text-foreground",
    outline: "border border-border text-foreground hover:bg-muted",
    danger: "bg-red-500 text-white hover:bg-red-600",
    accent: "bg-accent text-accent-foreground hover:bg-accent/80",
  };
  return (
    <button onClick={onClick} disabled={disabled}
      className={`inline-flex items-center justify-center gap-2 font-medium transition-all duration-150 cursor-pointer shrink-0 min-h-[44px] ${s[size]} ${v[variant]} ${disabled ? "opacity-40 cursor-not-allowed" : ""} ${className}`}>
      {children}
    </button>
  );
}

function KPICard({ title, value, subtitle, icon: Icon, trend, accentColor = false, compact = false }: {
  title: string; value: string; subtitle?: string; icon: React.ElementType;
  trend?: number; accentColor?: boolean; compact?: boolean;
}) {
  return (
    <div className={`rounded-2xl flex flex-col gap-2 shadow-sm border border-border/50 ${compact ? "p-4" : "p-5"} ${accentColor ? "bg-accent text-accent-foreground" : "bg-card"}`}>
      <div className="flex items-start justify-between">
        <div className={`rounded-xl flex items-center justify-center ${compact ? "w-9 h-9" : "w-10 h-10"} ${accentColor ? "bg-foreground/10" : "bg-primary/10"}`}>
          <Icon size={compact ? 17 : 19} className={accentColor ? "text-foreground" : "text-primary"} />
        </div>
        {trend !== undefined && (
          <div className={`flex items-center gap-1 text-xs font-semibold ${trend >= 0 ? "text-green-600" : "text-red-500"}`}>
            {trend >= 0 ? <ArrowUpRight size={13} /> : <TrendingDown size={13} />}
            {Math.abs(trend)}%
          </div>
        )}
      </div>
      <div>
        <div className={`font-bold tracking-tight ${compact ? "text-xl" : "text-2xl"}`}>{value}</div>
        <div className="text-sm font-semibold mt-0.5 opacity-80">{title}</div>
        {subtitle && !compact && <div className="text-xs mt-0.5 opacity-50">{subtitle}</div>}
      </div>
    </div>
  );
}

// ── Bottom Sheet ───────────────────────────────────────────────────────────
function BottomSheet({ isOpen, onClose, title, children, fullHeight = false }: {
  isOpen: boolean; onClose: () => void; title?: string; children: React.ReactNode; fullHeight?: boolean;
}) {
  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex flex-col justify-end">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className={`relative bg-card rounded-t-3xl shadow-2xl flex flex-col ${fullHeight ? "max-h-[92vh]" : "max-h-[85vh]"} overflow-hidden`}>
        <div className="flex justify-center pt-3 pb-1 shrink-0">
          <div className="w-10 h-1 bg-border rounded-full" />
        </div>
        {title && (
          <div className="flex items-center justify-between px-5 pt-2 pb-3 border-b border-border/50 shrink-0">
            <h3 className="font-bold text-foreground text-base">{title}</h3>
            <button onClick={onClose} className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center cursor-pointer"><X size={15} /></button>
          </div>
        )}
        <div className="flex-1 overflow-y-auto">{children}</div>
      </div>
    </div>
  );
}

// ── Nav Items ──────────────────────────────────────────────────────────────
const allNavItems = [
  { id: "dashboard", label: "Inicio", icon: LayoutDashboard },
  { id: "pos", label: "Punto de Venta", icon: ShoppingCart },
  { id: "inventory", label: "Inventario", icon: Package },
  { id: "reports", label: "Reportes", icon: BarChart3 },
  { id: "ai", label: "Asistente IA", icon: Bot },
  { id: "settings", label: "Configuracion", icon: Settings },
  { id: "help", label: "Ayuda", icon: HelpCircle },
];
const bottomNavItems = allNavItems.slice(0, 5);

// ── Mobile Drawer ──────────────────────────────────────────────────────────
function MobileDrawer({ isOpen, onClose, activeModule, setActiveModule, onLogout }: {
  isOpen: boolean; onClose: () => void; activeModule: string;
  setActiveModule: (m: string) => void; onLogout: () => void;
}) {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-50 flex">
      <div className="flex-1 bg-black/50" onClick={onClose} />
      <div className="w-72 bg-foreground h-full flex flex-col shadow-2xl">
        <div className="px-5 py-6 border-b border-white/8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center"><ShoppingBag size={17} className="text-white" /></div>
            <div><div className="text-white font-bold text-sm">RetailOS</div><div className="text-white/35 text-xs">Abarrotes El Roble</div></div>
          </div>
          <button onClick={onClose} className="w-9 h-9 rounded-xl bg-white/8 flex items-center justify-center cursor-pointer"><X size={17} className="text-white/60" /></button>
        </div>
        <nav className="flex-1 px-3 py-4 flex flex-col gap-1 overflow-y-auto">
          {allNavItems.map(item => {
            const Icon = item.icon;
            const isActive = activeModule === item.id;
            return (
              <button key={item.id} onClick={() => { setActiveModule(item.id); onClose(); }}
                className={`w-full flex items-center gap-3 px-4 py-3.5 rounded-xl text-sm font-medium cursor-pointer text-left min-h-[52px] transition-colors ${isActive ? "bg-primary text-white" : "text-white/60 hover:text-white hover:bg-white/8"}`}>
                <Icon size={18} />
                <span className="flex-1">{item.label}</span>
                {item.id === "ai" && <span className="bg-accent text-foreground text-[10px] px-1.5 py-0.5 rounded-full font-bold">IA</span>}
              </button>
            );
          })}
        </nav>
        <div className="px-3 pb-6 border-t border-white/8 pt-3">
          <div className="bg-white/6 rounded-xl px-3 py-2.5 mb-2">
            <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-secondary rounded-full" /><span className="text-white/60 text-xs">Negocio abierto</span></div>
            <div className="text-white text-sm font-bold mt-0.5">$12,450 hoy</div>
          </div>
          <button onClick={() => { onLogout(); onClose(); }} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-white/45 hover:text-white hover:bg-white/8 text-sm cursor-pointer min-h-[44px] transition-colors">
            <LogOut size={17} />Cerrar sesion
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Bottom Nav ─────────────────────────────────────────────────────────────
function BottomNav({ activeModule, setActiveModule, cartCount = 0 }: {
  activeModule: string; setActiveModule: (m: string) => void; cartCount?: number;
}) {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border">
      <div className="flex items-center">
        {bottomNavItems.map(item => {
          const Icon = item.icon;
          const isActive = activeModule === item.id;
          return (
            <button key={item.id} onClick={() => setActiveModule(item.id)}
              className={`flex-1 flex flex-col items-center gap-1 py-2.5 min-h-[64px] relative cursor-pointer transition-colors ${isActive ? "text-primary" : "text-muted-foreground"}`}>
              <div className="relative">
                <Icon size={22} strokeWidth={isActive ? 2.5 : 1.8} />
                {item.id === "pos" && cartCount > 0 && (
                  <span className="absolute -top-1.5 -right-1.5 w-4 h-4 bg-primary text-white text-[9px] font-bold rounded-full flex items-center justify-center">{cartCount > 9 ? "9+" : cartCount}</span>
                )}
              </div>
              <span className="text-[10px] font-semibold leading-none">{item.label}</span>
              {isActive && <div className="absolute top-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-primary rounded-full" />}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

// ── Sidebar (Tablet/Desktop) ───────────────────────────────────────────────
function Sidebar({ activeModule, setActiveModule, onLogout, collapsed, onToggleCollapse }: {
  activeModule: string; setActiveModule: (m: string) => void; onLogout: () => void;
  collapsed: boolean; onToggleCollapse: () => void;
}) {
  return (
    <aside className={`h-screen bg-foreground flex flex-col shrink-0 transition-all duration-300 ${collapsed ? "w-16" : "w-[228px]"}`}>
      <div className={`border-b border-white/8 flex items-center ${collapsed ? "px-3 py-5 justify-center" : "px-5 py-5"}`}>
        {collapsed ? (
          <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center"><ShoppingBag size={17} className="text-white" /></div>
        ) : (
          <div className="flex items-center gap-3 flex-1">
            <div className="w-9 h-9 bg-primary rounded-xl flex items-center justify-center shadow-sm"><ShoppingBag size={17} className="text-white" /></div>
            <div><div className="text-white font-bold text-sm leading-tight">RetailOS</div><div className="text-white/35 text-xs">Abarrotes El Roble</div></div>
          </div>
        )}
      </div>
      <nav className="flex-1 px-2 py-4 flex flex-col gap-0.5 overflow-y-auto">
        {allNavItems.map(item => {
          const Icon = item.icon;
          const isActive = activeModule === item.id;
          return (
            <button key={item.id} onClick={() => setActiveModule(item.id)} title={collapsed ? item.label : undefined}
              className={`w-full flex items-center gap-3 rounded-xl text-sm font-medium transition-all cursor-pointer ${collapsed ? "px-0 py-3 justify-center" : "px-3 py-2.5 text-left"} ${isActive ? "bg-primary text-white shadow-sm" : "text-white/55 hover:text-white hover:bg-white/8"}`}>
              <Icon size={17} className="shrink-0" />
              {!collapsed && (<><span className="flex-1">{item.label}</span>{item.id === "ai" && <span className="bg-accent text-foreground text-[10px] px-1.5 py-0.5 rounded-full font-bold">IA</span>}</>)}
            </button>
          );
        })}
      </nav>
      <div className={`border-t border-white/8 pt-3 pb-4 ${collapsed ? "px-2" : "px-3"}`}>
        {!collapsed && (
          <div className="bg-white/6 rounded-xl px-3 py-2.5 mb-2">
            <div className="flex items-center gap-2"><div className="w-1.5 h-1.5 bg-secondary rounded-full" /><span className="text-white/60 text-xs">Negocio abierto</span></div>
            <div className="text-white text-sm font-bold mt-0.5">$12,450 hoy</div>
          </div>
        )}
        <button onClick={onToggleCollapse} className="w-full flex items-center justify-center py-2 rounded-xl text-white/35 hover:text-white hover:bg-white/8 cursor-pointer min-h-[44px] transition-all">
          {collapsed ? <PanelLeftOpen size={16} /> : <PanelLeftClose size={16} />}
        </button>
        <button onClick={onLogout} className={`w-full flex items-center gap-3 rounded-xl text-white/45 hover:text-white hover:bg-white/8 text-sm cursor-pointer min-h-[44px] transition-all ${collapsed ? "justify-center px-0 py-3" : "px-3 py-2.5"}`} title={collapsed ? "Salir" : undefined}>
          <LogOut size={16} />{!collapsed && "Cerrar sesion"}
        </button>
      </div>
    </aside>
  );
}

// ── Header ─────────────────────────────────────────────────────────────────
const moduleTitles: Record<string, string> = {
  dashboard: "Dashboard", pos: "Punto de Venta", inventory: "Inventario",
  reports: "Reportes", ai: "Asistente IA", settings: "Configuracion", help: "Ayuda",
};

function Header({ activeModule, isMobile, onMenuOpen }: { activeModule: string; isMobile: boolean; onMenuOpen: () => void }) {
  const [showSearch, setShowSearch] = useState(false);
  if (isMobile) {
    return (
      <header className="h-14 bg-card border-b border-border flex items-center px-4 gap-3 shrink-0 sticky top-0 z-30">
        {showSearch ? (
          <>
            <div className="relative flex-1">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
              <input autoFocus placeholder="Buscar..." className="w-full pl-8 pr-3 py-2.5 rounded-xl bg-muted border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 min-h-[44px]" />
            </div>
            <button onClick={() => setShowSearch(false)} className="w-9 h-9 flex items-center justify-center text-muted-foreground cursor-pointer"><X size={18} /></button>
          </>
        ) : (
          <>
            <div className="flex-1 flex items-center gap-2">
              <div className="w-7 h-7 bg-primary rounded-lg flex items-center justify-center"><ShoppingBag size={14} className="text-white" /></div>
              <h1 className="text-sm font-bold text-foreground">{moduleTitles[activeModule]}</h1>
            </div>
            <button onClick={() => setShowSearch(true)} className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center text-muted-foreground cursor-pointer min-w-[36px]"><Search size={17} /></button>
            <button className="relative w-9 h-9 rounded-xl bg-muted flex items-center justify-center text-muted-foreground cursor-pointer min-w-[36px]">
              <Bell size={17} /><span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-card" />
            </button>
            <button onClick={onMenuOpen} className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center cursor-pointer min-w-[36px]"><Menu size={18} className="text-foreground" /></button>
          </>
        )}
      </header>
    );
  }
  return (
    <header className="h-16 bg-card border-b border-border flex items-center px-6 gap-4 shrink-0">
      <div className="flex-1"><h1 className="text-base font-bold text-foreground">{moduleTitles[activeModule]}</h1></div>
      <div className="relative w-64">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
        <input placeholder="Buscar productos, ventas..." className="w-full pl-9 pr-4 py-2 rounded-xl bg-muted border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all" />
      </div>
      <div className="flex items-center gap-2">
        <button className="relative w-9 h-9 rounded-xl bg-muted flex items-center justify-center text-muted-foreground hover:text-foreground cursor-pointer">
          <Bell size={17} /><span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border border-card" />
        </button>
        <div className="flex items-center gap-2.5 pl-3 border-l border-border ml-1 cursor-pointer">
          <div className="w-8 h-8 bg-primary rounded-xl flex items-center justify-center shadow-sm"><span className="text-white text-xs font-bold">JR</span></div>
          <div className="hidden md:block">
            <div className="text-sm font-semibold text-foreground leading-tight">Juan Reyes</div>
            <div className="text-xs text-muted-foreground">Administrador</div>
          </div>
          <ChevronDown size={13} className="text-muted-foreground" />
        </div>
      </div>
    </header>
  );
}

// ── Login Screen ────────────────────────────────────────────────────────────
function LoginScreen({ onLogin }: { onLogin: () => void }) {
  const { isMobile } = useBreakpoint();
  const [email, setEmail] = useState("admin@elroble.mx");
  const [password, setPassword] = useState("password123");
  const [remember, setRemember] = useState(true);
  const [loading, setLoading] = useState(false);
  const handleLogin = () => { setLoading(true); setTimeout(() => { setLoading(false); onLogin(); }, 1000); };

  const formContent = (
    <div className="flex flex-col gap-5">
      <div>
        <label className="block text-sm font-semibold text-foreground mb-1.5">Correo electronico</label>
        <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="admin@mitienda.mx"
          className="w-full px-4 py-3.5 rounded-xl border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/25 focus:border-primary transition-all text-sm min-h-[52px]" />
      </div>
      <div>
        <label className="block text-sm font-semibold text-foreground mb-1.5">Contrasena</label>
        <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="password"
          className="w-full px-4 py-3.5 rounded-xl border border-border bg-card text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/25 focus:border-primary transition-all text-sm min-h-[52px]" />
      </div>
      <div className="flex items-center justify-between">
        <label className="flex items-center gap-2 cursor-pointer min-h-[44px]">
          <input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)} className="w-4 h-4 accent-primary cursor-pointer" />
          <span className="text-sm text-muted-foreground">Recordarme</span>
        </label>
        <button className="text-sm text-primary hover:underline font-medium min-h-[44px] px-2">Olvide mi contrasena</button>
      </div>
      <button onClick={handleLogin} disabled={loading}
        className="w-full py-4 bg-primary text-white font-semibold rounded-xl hover:bg-secondary transition-colors disabled:opacity-70 flex items-center justify-center gap-2 text-sm cursor-pointer min-h-[52px]">
        {loading ? <><RefreshCw size={15} className="animate-spin" />Iniciando sesion...</> : "Iniciar sesion"}
      </button>
    </div>
  );

  if (isMobile) {
    return (
      <div className="min-h-screen bg-background flex flex-col">
        <div className="bg-foreground px-6 pt-14 pb-12 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-primary/25 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4 pointer-events-none" />
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-secondary/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/4 pointer-events-none" />
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center"><ShoppingBag size={20} className="text-white" /></div>
              <span className="text-xl font-bold text-white">RetailOS</span>
            </div>
            <h1 className="text-2xl font-bold text-white leading-tight">Bienvenido de vuelta</h1>
            <p className="text-white/55 text-sm mt-1">Accede a tu panel de administracion</p>
            <div className="flex gap-2 mt-4 flex-wrap">
              {["POS", "Inventario", "IA", "Reportes"].map(f => (
                <span key={f} className="px-2.5 py-1 bg-white/10 border border-white/15 text-white/70 text-xs rounded-full">{f}</span>
              ))}
            </div>
          </div>
        </div>
        <div className="flex-1 px-6 py-8 bg-background -mt-3 rounded-t-3xl shadow-lg">
          {formContent}
          <p className="mt-8 text-xs text-muted-foreground text-center">RetailOS v2.4 - 2025 RetailOS Inc.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex">
      <div className="w-full max-w-md flex flex-col justify-center px-12 py-12 bg-background">
        <div className="mb-10">
          <div className="flex items-center gap-3 mb-10"><div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-sm"><ShoppingBag size={20} className="text-white" /></div><span className="text-xl font-bold text-foreground tracking-tight">RetailOS</span></div>
          <h1 className="text-3xl font-bold text-foreground leading-tight">Bienvenido de vuelta</h1>
          <p className="text-muted-foreground mt-2 text-sm">Accede a tu panel de administracion</p>
        </div>
        {formContent}
        <p className="mt-10 text-xs text-muted-foreground text-center">RetailOS v2.4 - 2025 RetailOS Inc.</p>
      </div>
      <div className="flex-1 bg-foreground relative overflow-hidden flex flex-col items-center justify-center p-14">
        <div className="absolute top-0 right-0 w-[500px] h-[500px] rounded-full bg-primary/25 blur-3xl -translate-y-1/3 translate-x-1/4 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full bg-secondary/20 blur-3xl translate-y-1/3 -translate-x-1/4 pointer-events-none" />
        <div className="relative z-10 w-full max-w-sm">
          <div className="bg-white/10 backdrop-blur-sm border border-white/15 rounded-2xl p-4 mb-4">
            <div className="flex items-center gap-3 mb-2">
              <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: "rgba(235,213,171,0.25)" }}><TrendingUp size={15} className="text-accent" /></div>
              <span className="text-white/60 text-xs font-medium">Ventas del mes</span>
            </div>
            <div className="text-white text-2xl font-bold">$342,800</div>
            <div className="flex items-center gap-1.5 mt-1"><ArrowUpRight size={13} className="text-secondary" /><span className="text-secondary text-xs font-semibold">+12.4% vs mes anterior</span></div>
          </div>
          <div className="bg-primary/40 backdrop-blur-sm border border-primary/30 rounded-2xl p-4 ml-8 mb-8">
            <div className="flex items-center gap-2 mb-2"><Sparkles size={14} className="text-accent" /><span className="text-accent text-xs font-semibold">Asistente IA</span></div>
            <p className="text-white/85 text-sm leading-relaxed">Las bebidas representan el 35% de tus ventas. Considera ampliar ese inventario este fin de semana.</p>
          </div>
          <div className="text-center">
            <h2 className="text-white text-2xl font-bold leading-tight mb-3">Tu tienda, gestionada con inteligencia</h2>
            <p className="text-white/55 text-sm leading-relaxed">CRM + POS + Inventario + IA en una sola plataforma.</p>
            <div className="flex flex-wrap justify-center gap-2 mt-5">
              {["POS en tiempo real", "IA conversacional", "Reportes avanzados", "Alertas de stock"].map(f => (
                <span key={f} className="px-3 py-1.5 bg-white/10 border border-white/15 text-white/70 text-xs rounded-full">{f}</span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Dashboard ───────────────────────────────────────────────────────────────
function DashboardScreen() {
  const { isMobile, isTablet } = useBreakpoint();
  const [chartPeriod, setChartPeriod] = useState("7D");
  const kpi1 = isMobile ? "grid-cols-1" : isTablet ? "grid-cols-2" : "grid-cols-4";
  const kpi2 = isMobile ? "grid-cols-1" : "grid-cols-3";
  const chartGrid = isMobile || isTablet ? "grid-cols-1" : "grid-cols-3";
  const bottomGrid = isMobile ? "grid-cols-1" : "grid-cols-2";
  const aiGrid = isMobile ? "grid-cols-1" : "grid-cols-3";

  return (
    <div className="space-y-4 pb-6">
      <div className={`grid ${kpi1} gap-3`}>
        <KPICard title="Ventas de hoy" value="$12,450" subtitle="67 transacciones" icon={DollarSign} trend={8.3} compact={isMobile} />
        <KPICard title="Ventas semana" value="$84,230" subtitle="vs $78,940 anterior" icon={TrendingUp} trend={6.7} compact={isMobile} />
        <KPICard title="Ventas del mes" value="$342,800" subtitle="Meta: $380,000" icon={BarChart3} trend={12.4} compact={isMobile} />
        <KPICard title="Ganancia neta" value="$89,128" subtitle="Margen 26.0%" icon={Zap} trend={4.2} accentColor compact={isMobile} />
      </div>
      <div className={`grid ${kpi2} gap-3`}>
        <KPICard title="Productos vendidos" value="1,247" icon={ShoppingBasket} trend={5.1} compact={isMobile} />
        <KPICard title="Stock bajo" value="8 productos" icon={AlertTriangle} compact={isMobile} />
        <KPICard title="Ticket promedio" value="$187.50" icon={Tag} trend={8.3} compact={isMobile} />
      </div>

      <div className={`grid ${chartGrid} gap-4`}>
        <div className={`bg-card rounded-2xl p-4 border border-border/50 shadow-sm ${!isMobile && !isTablet ? "col-span-2" : ""}`}>
          <div className="flex items-center justify-between mb-4">
            <div><h3 className="font-bold text-foreground text-sm">Ventas y ganancias</h3><p className="text-xs text-muted-foreground">Tendencia por periodo</p></div>
            <div className="flex gap-1 bg-muted rounded-xl p-1">
              {["7D", "30D", "90D"].map(p => (
                <button key={p} onClick={() => setChartPeriod(p)} className={`px-2.5 py-1.5 text-xs rounded-lg font-medium cursor-pointer ${p === chartPeriod ? "bg-primary text-white" : "text-muted-foreground"}`}>{p}</button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={isMobile ? 160 : 200}>
            <AreaChart data={salesChartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="gV2" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#628141" stopOpacity={0.25} /><stop offset="95%" stopColor="#628141" stopOpacity={0} /></linearGradient>
                <linearGradient id="gG2" x1="0" y1="0" x2="0" y2="1"><stop offset="5%" stopColor="#EBD5AB" stopOpacity={0.4} /><stop offset="95%" stopColor="#EBD5AB" stopOpacity={0} /></linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(27,33,26,0.06)" />
              <XAxis dataKey="dia" tick={{ fontSize: 10, fill: "#7A7F73" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#7A7F73" }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => [`$${v.toLocaleString()}`, ""]} contentStyle={{ borderRadius: "12px", border: "1px solid rgba(27,33,26,0.1)", fontSize: "11px" }} />
              <Area type="monotone" dataKey="ventas" stroke="#628141" strokeWidth={2.5} fill="url(#gV2)" name="Ventas" />
              <Area type="monotone" dataKey="ganancia" stroke="#C4A87A" strokeWidth={2} fill="url(#gG2)" name="Ganancia" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
        <div className="bg-card rounded-2xl p-4 border border-border/50 shadow-sm">
          <h3 className="font-bold text-foreground text-sm mb-1">Categorias</h3>
          <p className="text-xs text-muted-foreground mb-3">Ventas del mes</p>
          <ResponsiveContainer width="100%" height={130}>
            <PieChart>
              <Pie data={categoryData} cx="50%" cy="50%" innerRadius={35} outerRadius={55} paddingAngle={4} dataKey="value">
                {categoryData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip formatter={(v: number) => [`${v}%`, ""]} contentStyle={{ borderRadius: "12px", border: "1px solid rgba(27,33,26,0.1)", fontSize: "11px" }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-2">
            {categoryData.map(c => (
              <div key={c.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full" style={{ background: c.color }} /><span className="text-muted-foreground">{c.name}</span></div>
                <span className="font-bold text-foreground">{c.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className={`grid ${bottomGrid} gap-4`}>
        <div className="bg-card rounded-2xl p-4 border border-border/50 shadow-sm">
          <div className="flex items-center justify-between mb-3"><h3 className="font-bold text-foreground text-sm">Mas vendidos</h3><Btn variant="ghost" size="sm">Ver todos</Btn></div>
          <div className="space-y-3">
            {topProducts.map((p, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-7 h-7 bg-primary/10 rounded-lg flex items-center justify-center text-xs font-bold text-primary shrink-0">{i + 1}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-foreground truncate">{p.nombre}</div>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden"><div className="h-full bg-primary rounded-full" style={{ width: `${(p.ventas / 342) * 100}%` }} /></div>
                    <span className="text-xs text-muted-foreground shrink-0">{p.ventas}</span>
                  </div>
                </div>
                <div className="text-sm font-bold text-foreground">${p.ingresos.toLocaleString()}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-2xl p-4 border border-border/50 shadow-sm">
          <div className="flex items-center justify-between mb-3"><h3 className="font-bold text-foreground text-sm">Actividad reciente</h3><Btn variant="ghost" size="sm">Ver todo</Btn></div>
          <div className="space-y-2.5">
            {recentSales.map(sale => (
              <div key={sale.id} className="flex items-center gap-3 py-0.5">
                <div className="w-8 h-8 bg-green-50 border border-green-100 rounded-xl flex items-center justify-center shrink-0"><CheckCircle size={14} className="text-green-600" /></div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm font-semibold text-foreground">{sale.id}</div>
                  <div className="text-xs text-muted-foreground">{sale.cliente} - {sale.hora}</div>
                </div>
                <div className="text-sm font-bold text-foreground">${sale.total.toLocaleString()}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-foreground rounded-2xl p-4 shadow-sm">
        <div className="flex items-center gap-2 mb-3"><Sparkles size={16} className="text-accent" /><h3 className="font-bold text-white text-sm">Recomendaciones IA</h3><Badge variant="info">3 nuevas</Badge></div>
        <div className={`grid ${aiGrid} gap-3`}>
          {[
            { title: "Reabastecer urgente", desc: "Sabritas Original y Arroz La Merced requieren pedido hoy.", icon: AlertTriangle, color: "text-amber-400" },
            { title: "Oportunidad de venta", desc: "Las bebidas tienen alta rotacion los viernes. Considera 2x1.", icon: Star, color: "text-accent" },
            { title: "Tendencia positiva", desc: "Tus ventas llevan 3 semanas por encima de la meta. Excelente!", icon: TrendingUp, color: "text-secondary" },
          ].map((r, i) => (
            <div key={i} className="bg-white/6 border border-white/10 rounded-xl p-4 cursor-pointer hover:bg-white/10 transition-colors">
              <r.icon size={16} className={`${r.color} mb-2`} />
              <div className="text-white text-sm font-semibold mb-1">{r.title}</div>
              <div className="text-white/55 text-xs leading-relaxed">{r.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ── POS Screen ──────────────────────────────────────────────────────────────
interface CartItem { id: number; codigo: string; nombre: string; precio: number; categoria: string; qty: number; }

function POSScreen() {
  const { isMobile, isTablet } = useBreakpoint();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [search, setSearch] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("efectivo");
  const [cashAmount, setCashAmount] = useState("");
  const [showTicket, setShowTicket] = useState(false);
  const [activeCategory, setActiveCategory] = useState("Todos");
  const [showCart, setShowCart] = useState(false);
  const [showPayment, setShowPayment] = useState(false);

  const categories = ["Todos", "Bebidas", "Lacteos", "Botanas", "Abarrotes", "Panaderia"];
  const filtered = posProducts.filter(p => {
    const ms = p.nombre.toLowerCase().includes(search.toLowerCase()) || p.codigo.includes(search);
    const mc = activeCategory === "Todos" || p.categoria === activeCategory;
    return ms && mc;
  });

  const addToCart = (product: typeof posProducts[0]) => {
    setCart(prev => {
      const ex = prev.find(i => i.id === product.id);
      if (ex) return prev.map(i => i.id === product.id ? { ...i, qty: i.qty + 1 } : i);
      return [...prev, { ...product, qty: 1 }];
    });
  };
  const updateQty = (id: number, qty: number) => {
    if (qty <= 0) setCart(prev => prev.filter(i => i.id !== id));
    else setCart(prev => prev.map(i => i.id === id ? { ...i, qty } : i));
  };

  const subtotal = cart.reduce((s, i) => s + i.precio * i.qty, 0);
  const iva = subtotal * 0.16;
  const total = subtotal + iva;
  const cashVal = parseFloat(cashAmount) || 0;
  const change = cashVal - total;
  const totalItems = cart.reduce((s, i) => s + i.qty, 0);
  const newSale = () => { setCart([]); setShowTicket(false); setCashAmount(""); setShowCart(false); setShowPayment(false); };

  const CartItems = () => (
    <>
      {cart.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
          <ShoppingCart size={36} className="mb-3 opacity-20" />
          <p className="text-sm font-medium">Carrito vacio</p>
          <p className="text-xs opacity-60">Toca un producto para agregarlo</p>
        </div>
      ) : cart.map(item => (
        <div key={item.id} className="flex items-center gap-3 bg-muted rounded-xl px-3 py-3 min-h-[60px]">
          <div className="flex-1 min-w-0">
            <div className="text-sm font-bold text-foreground truncate">{item.nombre}</div>
            <div className="text-xs text-primary font-semibold">${item.precio.toFixed(2)} c/u</div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <button onClick={() => updateQty(item.id, item.qty - 1)} className="w-8 h-8 rounded-xl bg-card border border-border text-foreground flex items-center justify-center font-bold cursor-pointer text-base min-w-[32px]">-</button>
            <span className="w-6 text-center text-sm font-bold text-foreground">{item.qty}</span>
            <button onClick={() => updateQty(item.id, item.qty + 1)} className="w-8 h-8 rounded-xl bg-primary text-white flex items-center justify-center font-bold cursor-pointer text-base min-w-[32px]">+</button>
          </div>
          <div className="text-sm font-bold text-foreground w-16 text-right shrink-0">${(item.precio * item.qty).toFixed(2)}</div>
        </div>
      ))}
    </>
  );

  const Totals = () => (
    <div className="px-4 pt-3 pb-1 border-t border-border/50 space-y-1.5 bg-muted/30">
      <div className="flex justify-between text-xs text-muted-foreground"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
      <div className="flex justify-between text-xs text-muted-foreground"><span>IVA 16%</span><span>${iva.toFixed(2)}</span></div>
      <div className="flex justify-between font-bold text-base text-foreground pt-1.5 border-t border-border/50">
        <span>Total</span><span className="text-primary">${total.toFixed(2)}</span>
      </div>
    </div>
  );

  const PaymentPanel = () => (
    <div className="space-y-4">
      <h3 className="font-bold text-foreground text-sm">Metodo de pago</h3>
      <div className="grid grid-cols-3 gap-2">
        {[{ id: "efectivo", label: "Efectivo", icon: Banknote }, { id: "transferencia", label: "Transfer.", icon: Smartphone }, { id: "terminal", label: "Terminal", icon: CreditCard }].map(m => (
          <button key={m.id} onClick={() => setPaymentMethod(m.id)}
            className={`flex flex-col items-center gap-1.5 p-3 rounded-xl border text-xs font-semibold cursor-pointer min-h-[64px] transition-all ${paymentMethod === m.id ? "border-primary bg-primary/10 text-primary" : "border-border text-muted-foreground"}`}>
            <m.icon size={18} />{m.label}
          </button>
        ))}
      </div>
      {paymentMethod === "efectivo" && (
        <div>
          <label className="text-xs font-semibold text-muted-foreground">Efectivo recibido</label>
          <input type="number" value={cashAmount} onChange={e => setCashAmount(e.target.value)} placeholder="0.00"
            className="w-full mt-1.5 px-3 py-3 rounded-xl border border-border bg-muted text-foreground text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 min-h-[48px]" />
          {cashAmount && change >= 0 && (
            <div className="mt-2 flex justify-between items-center bg-green-50 border border-green-100 rounded-xl px-3 py-2.5">
              <span className="text-sm text-green-700 font-medium">Cambio</span>
              <span className="text-green-700 font-bold text-base">${change.toFixed(2)}</span>
            </div>
          )}
        </div>
      )}
      <button onClick={() => setShowTicket(true)} disabled={cart.length === 0}
        className="w-full py-4 bg-primary text-white font-bold rounded-xl hover:bg-secondary transition-colors disabled:opacity-40 cursor-pointer text-sm min-h-[56px]">
        Cobrar ${total.toFixed(2)}
      </button>
    </div>
  );

  const TicketPanel = () => (
    <div className="flex flex-col h-full p-4">
      <div className="flex items-center gap-2.5 mb-4">
        <div className="w-9 h-9 bg-green-100 rounded-xl flex items-center justify-center"><CheckCircle size={18} className="text-green-600" /></div>
        <div><div className="font-bold text-foreground text-sm">Venta completada</div><div className="text-xs text-muted-foreground">Ticket #V-1048</div></div>
      </div>
      <div className="bg-muted rounded-xl p-4 flex-1 overflow-y-auto font-mono text-xs text-foreground">
        <div className="text-center mb-3">
          <div className="font-bold text-sm">Abarrotes El Roble</div>
          <div className="text-muted-foreground">Calle Principal 45, CDMX</div>
          <div className="text-muted-foreground">{new Date().toLocaleString("es-MX")}</div>
        </div>
        <div className="border-t border-dashed border-border my-2" />
        {cart.map(item => (<div key={item.id} className="flex justify-between py-0.5"><span className="truncate mr-2">{item.nombre} x{item.qty}</span><span className="shrink-0">${(item.precio * item.qty).toFixed(2)}</span></div>))}
        <div className="border-t border-dashed border-border my-2" />
        <div className="flex justify-between"><span>Subtotal</span><span>${subtotal.toFixed(2)}</span></div>
        <div className="flex justify-between"><span>IVA 16%</span><span>${iva.toFixed(2)}</span></div>
        <div className="flex justify-between font-bold border-t border-dashed border-border mt-1 pt-1"><span>TOTAL</span><span>${total.toFixed(2)}</span></div>
      </div>
      <div className="flex flex-col gap-2 mt-4">
        <Btn variant="primary" className="w-full min-h-[48px]"><MessageCircle size={15} />WhatsApp</Btn>
        <Btn variant="outline" className="w-full min-h-[48px]"><Mail size={15} />Correo</Btn>
        <Btn variant="outline" className="w-full min-h-[48px]"><Download size={15} />PDF</Btn>
        <Btn variant="secondary" onClick={newSale} className="w-full min-h-[48px]">Nueva venta</Btn>
      </div>
    </div>
  );

  if (isMobile) {
    return (
      <div className="flex flex-col" style={{ height: "calc(100vh - 56px - 64px)" }}>
        <div className="px-0 py-2 bg-card border-b border-border/50 flex gap-2 shrink-0">
          <div className="relative flex-1">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar producto o codigo..."
              className="w-full pl-8 pr-3 py-3 rounded-xl border border-border bg-background text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 min-h-[48px]" />
          </div>
          <button className="w-12 h-12 bg-primary text-white rounded-xl flex items-center justify-center cursor-pointer shrink-0"><Scan size={20} /></button>
        </div>
        <div className="py-2 border-b border-border/30 shrink-0 overflow-x-auto flex gap-2">
          {categories.map(c => (
            <button key={c} onClick={() => setActiveCategory(c)}
              className={`px-3 py-2 text-xs rounded-xl font-semibold whitespace-nowrap cursor-pointer shrink-0 min-h-[36px] transition-colors ${c === activeCategory ? "bg-primary text-white" : "bg-muted text-muted-foreground"}`}>{c}</button>
          ))}
        </div>
        <div className="flex-1 overflow-y-auto py-2">
          <div className="grid grid-cols-2 gap-3">
            {filtered.map(p => (
              <button key={p.id} onClick={() => addToCart(p)}
                className="bg-card border border-border/50 rounded-2xl p-3.5 text-left active:scale-[0.97] transition-all cursor-pointer min-h-[100px]">
                <div className="w-9 h-9 bg-primary/10 rounded-xl flex items-center justify-center mb-2.5"><Package2 size={16} className="text-primary" /></div>
                <div className="text-xs font-bold text-foreground leading-snug mb-1">{p.nombre}</div>
                <div className="text-primary font-bold text-base">${p.precio.toFixed(2)}</div>
              </button>
            ))}
          </div>
        </div>
        <div className="py-3 bg-card border-t border-border shadow-lg shrink-0">
          {showTicket ? (
            <button onClick={newSale} className="w-full py-3.5 bg-secondary/20 text-primary font-bold rounded-xl cursor-pointer text-sm min-h-[52px]">
              Venta completada - Nueva venta
            </button>
          ) : (
            <button onClick={() => cart.length > 0 && setShowCart(true)} disabled={cart.length === 0}
              className="w-full py-3.5 bg-primary text-white font-bold rounded-xl cursor-pointer disabled:opacity-40 flex items-center justify-between px-5 min-h-[56px] hover:bg-secondary transition-colors">
              <div className="flex items-center gap-2"><ShoppingCart size={18} /><span>{totalItems > 0 ? `${totalItems} producto${totalItems > 1 ? "s" : ""}` : "Carrito vacio"}</span></div>
              <span className="text-lg font-black">${total.toFixed(2)}</span>
            </button>
          )}
        </div>

        <BottomSheet isOpen={showCart} onClose={() => setShowCart(false)} title="Carrito de venta" fullHeight>
          <div className="flex flex-col h-full">
            <div className="flex-1 overflow-y-auto p-4 space-y-2"><CartItems /></div>
            {cart.length > 0 && (
              <>
                <Totals />
                <div className="px-4 pb-6 pt-3">
                  <button onClick={() => { setShowCart(false); setShowPayment(true); }}
                    className="w-full py-4 bg-primary text-white font-bold rounded-xl text-sm cursor-pointer hover:bg-secondary transition-colors min-h-[56px]">
                    Continuar al pago
                  </button>
                </div>
              </>
            )}
          </div>
        </BottomSheet>

        <BottomSheet isOpen={showPayment} onClose={() => setShowPayment(false)} title="Metodo de pago" fullHeight>
          <div className="p-4">
            <div className="bg-muted rounded-xl px-4 py-3 mb-4 flex justify-between items-center">
              <div><div className="text-xs text-muted-foreground">{totalItems} productos</div><div className="text-lg font-bold text-foreground">Total: ${total.toFixed(2)}</div></div>
              <button onClick={() => { setShowPayment(false); setShowCart(true); }} className="text-xs text-primary font-semibold cursor-pointer">Editar carrito</button>
            </div>
            {showTicket ? <TicketPanel /> : <PaymentPanel />}
          </div>
        </BottomSheet>
      </div>
    );
  }

  return (
    <div className={`flex gap-4 pb-4 ${isTablet ? "h-[calc(100vh-128px)]" : "h-[calc(100vh-112px)]"}`}>
      <div className="flex-1 flex flex-col gap-4 min-w-0">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nombre o codigo de barras..."
              className="w-full pl-9 pr-4 py-2.5 rounded-xl border border-border bg-card text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all" />
          </div>
          <Btn variant="outline" size="md"><Scan size={15} />Escanear</Btn>
        </div>
        <div className="flex-1 bg-card rounded-2xl border border-border/50 overflow-hidden shadow-sm flex flex-col">
          <div className="px-4 py-3 border-b border-border/50">
            <div className="flex gap-1.5 flex-wrap">
              {categories.map(c => (
                <button key={c} onClick={() => setActiveCategory(c)} className={`px-3 py-1.5 text-xs rounded-xl font-medium cursor-pointer transition-all ${c === activeCategory ? "bg-primary text-white" : "text-muted-foreground hover:bg-muted"}`}>{c}</button>
              ))}
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4">
            <div className={`grid gap-3 ${isTablet ? "grid-cols-3" : "grid-cols-4"}`}>
              {filtered.map(p => (
                <button key={p.id} onClick={() => addToCart(p)}
                  className="bg-background hover:bg-primary/8 border border-border/50 hover:border-primary/30 rounded-xl p-3 text-left transition-all cursor-pointer group">
                  <div className="w-9 h-9 bg-primary/10 rounded-xl flex items-center justify-center mb-2.5 group-hover:bg-primary/20"><Package2 size={16} className="text-primary" /></div>
                  <div className="text-xs font-bold text-foreground leading-snug mb-1">{p.nombre}</div>
                  <div className="text-primary font-bold text-sm">${p.precio.toFixed(2)}</div>
                  <div className="text-muted-foreground text-xs mt-0.5">{p.categoria}</div>
                </button>
              ))}
            </div>
          </div>
        </div>
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
          <h3 className="font-bold text-foreground text-sm mb-3">Historial del dia</h3>
          <div className="space-y-2">
            {recentSales.slice(0, 3).map(s => (
              <div key={s.id} className="flex items-center gap-3 text-xs py-1">
                <CheckCircle size={13} className="text-green-500 shrink-0" />
                <span className="text-muted-foreground w-10 shrink-0">{s.hora}</span>
                <span className="font-semibold text-foreground flex-1">{s.id} - {s.cliente}</span>
                <Badge variant="success">{s.metodo}</Badge>
                <span className="font-bold text-foreground">${s.total.toLocaleString()}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="w-72 flex flex-col gap-4 shrink-0">
        {showTicket ? (
          <div className="flex-1 bg-card rounded-2xl border border-border/50 shadow-sm overflow-hidden"><TicketPanel /></div>
        ) : (
          <>
            <div className="flex-1 bg-card rounded-2xl border border-border/50 flex flex-col overflow-hidden shadow-sm">
              <div className="flex items-center justify-between px-4 py-3.5 border-b border-border/50">
                <h3 className="font-bold text-foreground text-sm">Carrito</h3>
                {cart.length > 0 && <button onClick={() => setCart([])} className="text-xs text-red-500 hover:underline cursor-pointer">Limpiar</button>}
              </div>
              <div className="flex-1 overflow-y-auto p-3 space-y-2"><CartItems /></div>
              {cart.length > 0 && <Totals />}
            </div>
            <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm"><PaymentPanel /></div>
          </>
        )}
      </div>
    </div>
  );
}

// ── Inventory Screen ────────────────────────────────────────────────────────
function InventoryScreen() {
  const { isMobile } = useBreakpoint();
  const [search, setSearch] = useState("");
  const [view, setView] = useState<"table" | "cards">(isMobile ? "cards" : "table");
  const [showModal, setShowModal] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  const filtered = inventoryProducts.filter(p =>
    p.nombre.toLowerCase().includes(search.toLowerCase()) ||
    p.sku.toLowerCase().includes(search.toLowerCase()) ||
    p.categoria.toLowerCase().includes(search.toLowerCase())
  );

  const estadoBadge = (e: string) => {
    if (e === "ok") return <Badge variant="success">En stock</Badge>;
    if (e === "bajo") return <Badge variant="warning">Stock bajo</Badge>;
    return <Badge variant="danger">Agotado</Badge>;
  };

  return (
    <div className="space-y-4 pb-6">
      <div className={`grid gap-3 ${isMobile ? "grid-cols-1" : "grid-cols-3"}`}>
        {[
          { bg: "bg-amber-50 border-amber-200", ibg: "bg-amber-100", Icon: AlertTriangle, ic: "text-amber-600", tc: "text-amber-700", t: "3 con stock bajo", d: "Leche, Arroz, Detergente" },
          { bg: "bg-red-50 border-red-200", ibg: "bg-red-100", Icon: XCircle, ic: "text-red-600", tc: "text-red-700", t: "1 producto agotado", d: "Sabritas Original 45g" },
          { bg: "bg-green-50 border-green-200", ibg: "bg-green-100", Icon: Package, ic: "text-green-600", tc: "text-green-700", t: "4 con nivel OK", d: "Inventario adecuado" },
        ].map((a, i) => (
          <div key={i} className={`border rounded-2xl p-4 flex items-center gap-3 ${a.bg}`}>
            <div className={`w-10 h-10 ${a.ibg} rounded-xl flex items-center justify-center shrink-0`}><a.Icon size={18} className={a.ic} /></div>
            <div><div className={`font-bold text-sm ${a.tc}`}>{a.t}</div><div className={`text-xs mt-0.5 ${a.ic}`}>{a.d}</div></div>
          </div>
        ))}
      </div>

      <div className={`flex gap-3 bg-card rounded-2xl border border-border/50 p-4 shadow-sm ${isMobile ? "flex-wrap" : "items-center"}`}>
        <div className="relative flex-1 min-w-0">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por nombre, SKU..."
            className="w-full pl-9 pr-4 py-2.5 rounded-xl bg-muted border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 min-h-[44px]" />
        </div>
        <div className="flex gap-2 shrink-0">
          <button onClick={() => setShowFilters(true)} className="flex items-center gap-2 px-3 py-2.5 rounded-xl border border-border text-sm font-medium text-foreground hover:bg-muted cursor-pointer min-h-[44px]">
            <Filter size={15} />{!isMobile && "Filtros"}
          </button>
          {!isMobile && (
            <div className="flex gap-1 bg-muted rounded-xl p-1">
              <button onClick={() => setView("table")} className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${view === "table" ? "bg-primary text-white" : "text-muted-foreground"}`}>Tabla</button>
              <button onClick={() => setView("cards")} className={`px-3 py-1.5 rounded-lg text-xs font-semibold cursor-pointer ${view === "cards" ? "bg-primary text-white" : "text-muted-foreground"}`}>Tarjetas</button>
            </div>
          )}
          <Btn variant="primary" size="md" onClick={() => setShowModal(true)}><Plus size={15} />{!isMobile && "Agregar"}</Btn>
        </div>
      </div>

      {(isMobile || view === "cards") && (
        <div className={`grid gap-4 ${isMobile ? "grid-cols-1" : "grid-cols-2 md:grid-cols-3 lg:grid-cols-4"}`}>
          {filtered.map(p => (
            <div key={p.id} className="bg-card rounded-2xl border border-border/50 p-4 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between mb-3">
                <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center"><Package2 size={17} className="text-primary" /></div>
                {estadoBadge(p.estado)}
              </div>
              <div className="text-sm font-bold text-foreground mb-0.5">{p.nombre}</div>
              <div className="text-xs text-muted-foreground mb-3">{p.sku} - {p.categoria}</div>
              <div className="grid grid-cols-2 gap-2">
                {[["Venta", `$${p.precio_venta}`, "text-foreground"], ["Margen", `${p.margen}%`, "text-primary"],
                  ["Stock", `${p.existencia} uds.`, p.existencia === 0 ? "text-red-500" : p.existencia < p.stock_min ? "text-amber-600" : "text-foreground"],
                  ["Minimo", `${p.stock_min} uds.`, "text-foreground"]].map(([l, v, c]) => (
                  <div key={l}><div className="text-xs text-muted-foreground">{l}</div><div className={`text-sm font-bold ${c}`}>{v}</div></div>
                ))}
              </div>
              {isMobile && (
                <div className="flex gap-2 mt-3 pt-3 border-t border-border/30">
                  <button className="flex-1 py-2 bg-muted rounded-xl text-xs font-semibold text-foreground cursor-pointer min-h-[40px] flex items-center justify-center gap-1"><Edit2 size={12} />Editar</button>
                  <button className="flex-1 py-2 bg-red-50 rounded-xl text-xs font-semibold text-red-500 cursor-pointer min-h-[40px] flex items-center justify-center gap-1"><Trash2 size={12} />Eliminar</button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}

      {!isMobile && view === "table" && (
        <div className="bg-card rounded-2xl border border-border/50 overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-border/50 bg-muted/50">
                  {["SKU", "Producto", "Categoria", "P. Compra", "P. Venta", "Margen", "Existencia", "Estado", "Acciones"].map(h => (
                    <th key={h} className={`px-4 py-3 text-xs font-bold text-muted-foreground ${["P. Compra", "P. Venta", "Margen"].includes(h) ? "text-right" : ["Existencia", "Estado", "Acciones"].includes(h) ? "text-center" : "text-left"}`}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((p, i) => (
                  <tr key={p.id} className={`border-b border-border/30 hover:bg-muted/40 transition-colors ${i % 2 === 1 ? "bg-muted/10" : ""}`}>
                    <td className="px-4 py-3 font-mono text-xs text-muted-foreground">{p.sku}</td>
                    <td className="px-4 py-3 text-sm font-semibold text-foreground">{p.nombre}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{p.categoria}</td>
                    <td className="px-4 py-3 text-sm text-right text-muted-foreground">${p.precio_compra.toFixed(2)}</td>
                    <td className="px-4 py-3 text-sm text-right font-semibold text-foreground">${p.precio_venta.toFixed(2)}</td>
                    <td className="px-4 py-3 text-sm text-right font-bold text-primary">{p.margen.toFixed(1)}%</td>
                    <td className="px-4 py-3 text-center"><span className={`font-bold text-sm ${p.existencia === 0 ? "text-red-500" : p.existencia < p.stock_min ? "text-amber-600" : "text-foreground"}`}>{p.existencia}</span><span className="text-xs text-muted-foreground">/{p.stock_min}</span></td>
                    <td className="px-4 py-3 text-center">{estadoBadge(p.estado)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        <button className="w-7 h-7 rounded-lg bg-muted hover:bg-border flex items-center justify-center cursor-pointer"><Eye size={13} className="text-muted-foreground" /></button>
                        <button className="w-7 h-7 rounded-lg bg-muted hover:bg-border flex items-center justify-center cursor-pointer"><Edit2 size={13} className="text-muted-foreground" /></button>
                        <button className="w-7 h-7 rounded-lg bg-red-50 hover:bg-red-100 flex items-center justify-center cursor-pointer"><Trash2 size={13} className="text-red-500" /></button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="px-4 py-3 border-t border-border/50 flex items-center justify-between">
            <span className="text-xs text-muted-foreground">{filtered.length} productos encontrados</span>
            <div className="flex gap-1">{[1, 2, 3].map(p => (<button key={p} className={`w-7 h-7 rounded-lg text-xs font-bold cursor-pointer ${p === 1 ? "bg-primary text-white" : "text-muted-foreground hover:bg-muted"}`}>{p}</button>))}</div>
          </div>
        </div>
      )}

      <BottomSheet isOpen={showFilters} onClose={() => setShowFilters(false)} title="Filtros">
        <div className="p-4 space-y-5">
          {[{ label: "Categoria", opts: ["Todas", "Bebidas", "Lacteos", "Botanas", "Abarrotes", "Limpieza"] }, { label: "Estado", opts: ["Todos", "En stock", "Stock bajo", "Agotado"] }].map(f => (
            <div key={f.label}>
              <label className="block text-sm font-bold text-foreground mb-2">{f.label}</label>
              <div className="flex flex-wrap gap-2">
                {f.opts.map(o => (<button key={o} className={`px-3 py-2 rounded-xl text-sm font-medium cursor-pointer border min-h-[44px] ${o.includes("Todas") || o.includes("Todos") ? "bg-primary text-white border-primary" : "border-border text-muted-foreground"}`}>{o}</button>))}
              </div>
            </div>
          ))}
          <Btn variant="primary" className="w-full min-h-[52px]" onClick={() => setShowFilters(false)}>Aplicar filtros</Btn>
        </div>
      </BottomSheet>

      {showModal && (
        <div className="fixed inset-0 bg-black/50 flex items-end md:items-center justify-center z-50 p-0 md:p-4" onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div className="bg-card rounded-t-3xl md:rounded-2xl shadow-2xl w-full md:max-w-lg p-6 border border-border">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-lg font-bold text-foreground">Agregar producto</h2>
              <button onClick={() => setShowModal(false)} className="w-9 h-9 rounded-xl bg-muted flex items-center justify-center cursor-pointer"><X size={15} /></button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {[{ label: "Nombre del producto", placeholder: "Coca-Cola 600ml", full: true }, { label: "SKU / Codigo", placeholder: "BEB-001" }, { label: "Codigo de barras", placeholder: "7501055300231" }, { label: "Categoria", placeholder: "Bebidas" }, { label: "Precio compra ($)", placeholder: "0.00" }, { label: "Precio venta ($)", placeholder: "0.00" }, { label: "Stock actual", placeholder: "0" }, { label: "Stock minimo", placeholder: "10" }].map(f => (
                <div key={f.label} className={f.full ? "col-span-2" : ""}>
                  <label className="block text-xs font-semibold text-muted-foreground mb-1.5">{f.label}</label>
                  <input placeholder={f.placeholder} className="w-full px-3 py-3 rounded-xl border border-border bg-muted text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 min-h-[48px]" />
                </div>
              ))}
            </div>
            <div className="flex gap-3 mt-5">
              <Btn variant="outline" onClick={() => setShowModal(false)} className="flex-1 min-h-[52px]">Cancelar</Btn>
              <Btn variant="primary" onClick={() => setShowModal(false)} className="flex-1 min-h-[52px]">Guardar producto</Btn>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ── Reports Screen ──────────────────────────────────────────────────────────
function ReportsScreen() {
  const { isMobile } = useBreakpoint();
  const [period, setPeriod] = useState("semana");
  const [showExport, setShowExport] = useState(false);

  return (
    <div className="space-y-4 pb-6">
      <div className={`flex gap-3 bg-card rounded-2xl border border-border/50 p-3 shadow-sm ${isMobile ? "flex-col" : "items-center justify-between"}`}>
        <div className="flex gap-1 bg-muted rounded-xl p-1 overflow-x-auto">
          {[{ id: "dia", l: "Dia" }, { id: "semana", l: "Semana" }, { id: "mes", l: "Mes" }, { id: "trimestre", l: "Trimestre" }].map(p => (
            <button key={p.id} onClick={() => setPeriod(p.id)} className={`px-3 py-2 rounded-xl text-sm font-semibold cursor-pointer whitespace-nowrap min-h-[40px] transition-all ${period === p.id ? "bg-primary text-white" : "text-muted-foreground"}`}>{p.l}</button>
          ))}
        </div>
        <div className="flex gap-2 shrink-0">
          {isMobile ? (
            <button onClick={() => setShowExport(true)} className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl border border-border text-sm font-medium cursor-pointer min-h-[44px]"><Download size={15} />Exportar</button>
          ) : (<><Btn variant="outline" size="sm"><Download size={13} />PDF</Btn><Btn variant="outline" size="sm"><Download size={13} />Excel</Btn><Btn variant="outline" size="sm"><Mail size={13} />Compartir</Btn></>)}
        </div>
      </div>

      <div className={`grid gap-3 ${isMobile ? "grid-cols-2" : "grid-cols-4"}`}>
        <KPICard title="Ventas totales" value="$84,230" icon={DollarSign} trend={6.7} compact={isMobile} />
        <KPICard title="Ganancia neta" value="$21,900" icon={TrendingUp} trend={4.2} accentColor compact={isMobile} />
        <KPICard title="Transacciones" value="452" icon={ShoppingCart} trend={3.1} compact={isMobile} />
        <KPICard title="Margen promedio" value="24.8%" icon={BarChart3} trend={1.2} compact={isMobile} />
      </div>

      <div className={`grid gap-4 ${isMobile ? "grid-cols-1" : "grid-cols-3"}`}>
        <div className={`bg-card rounded-2xl border border-border/50 p-4 shadow-sm ${isMobile ? "" : "col-span-2"}`}>
          <h3 className="font-bold text-foreground text-sm mb-1">Tendencia de ventas</h3>
          <p className="text-xs text-muted-foreground mb-4">Ventas vs Ganancias por dia</p>
          <div className={isMobile ? "overflow-x-auto" : ""}><div style={isMobile ? { minWidth: 280 } : {}}>
            <ResponsiveContainer width="100%" height={isMobile ? 150 : 200}>
              <BarChart data={salesChartData} margin={{ top: 5, right: 5, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(27,33,26,0.06)" />
                <XAxis dataKey="dia" tick={{ fontSize: 10, fill: "#7A7F73" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 10, fill: "#7A7F73" }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => [`$${v.toLocaleString()}`, ""]} contentStyle={{ borderRadius: "12px", border: "1px solid rgba(27,33,26,0.1)", fontSize: "11px" }} />
                <Bar dataKey="ventas" fill="#628141" radius={[5, 5, 0, 0]} name="Ventas" />
                <Bar dataKey="ganancia" fill="#EBD5AB" radius={[5, 5, 0, 0]} name="Ganancia" />
              </BarChart>
            </ResponsiveContainer>
          </div></div>
        </div>
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
          <h3 className="font-bold text-foreground text-sm mb-3">Rentabilidad por categoria</h3>
          <ResponsiveContainer width="100%" height={130}>
            <PieChart>
              <Pie data={categoryData} cx="50%" cy="50%" innerRadius={35} outerRadius={55} paddingAngle={4} dataKey="value">
                {categoryData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
              </Pie>
              <Tooltip formatter={(v: number) => [`${v}%`, ""]} contentStyle={{ borderRadius: "12px", border: "1px solid rgba(27,33,26,0.1)", fontSize: "11px" }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-1.5 mt-3">
            {categoryData.map(c => (
              <div key={c.name} className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-2"><div className="w-2 h-2 rounded-full" style={{ background: c.color }} /><span className="text-muted-foreground">{c.name}</span></div>
                <span className="font-bold text-foreground">{c.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div><h3 className="font-bold text-foreground text-sm">Ventas mensuales 2025</h3><p className="text-xs text-muted-foreground">Enero - Junio</p></div>
          <div className="text-right"><div className="text-lg font-bold text-foreground">$1,949,800</div><div className="text-xs text-muted-foreground">Acumulado YTD</div></div>
        </div>
        <div className={isMobile ? "overflow-x-auto" : ""}><div style={isMobile ? { minWidth: 280 } : {}}>
          <ResponsiveContainer width="100%" height={isMobile ? 130 : 160}>
            <LineChart data={monthlyData} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(27,33,26,0.06)" />
              <XAxis dataKey="mes" tick={{ fontSize: 10, fill: "#7A7F73" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 10, fill: "#7A7F73" }} axisLine={false} tickLine={false} tickFormatter={v => `$${(v / 1000).toFixed(0)}k`} />
              <Tooltip formatter={(v: number) => [`$${v.toLocaleString()}`, "Ventas"]} contentStyle={{ borderRadius: "12px", border: "1px solid rgba(27,33,26,0.1)", fontSize: "11px" }} />
              <Line type="monotone" dataKey="ventas" stroke="#628141" strokeWidth={2.5} dot={{ r: 4, fill: "#628141", strokeWidth: 0 }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        </div></div>
      </div>

      <div className={`grid gap-4 ${isMobile ? "grid-cols-1" : "grid-cols-2"}`}>
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
          <h3 className="font-bold text-foreground text-sm mb-4">Productos mas rentables</h3>
          <div className="space-y-3.5">
            {topProducts.map((p, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-7 h-7 bg-primary/10 rounded-lg flex items-center justify-center text-xs font-bold text-primary shrink-0">{i + 1}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex justify-between items-baseline mb-1.5"><span className="text-sm font-semibold text-foreground truncate">{p.nombre}</span><span className="text-xs font-bold text-primary ml-2 shrink-0">{p.margen}%</span></div>
                  <div className="h-1.5 bg-muted rounded-full overflow-hidden"><div className="h-full bg-primary rounded-full" style={{ width: `${(p.ventas / 342) * 100}%` }} /></div>
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
          <h3 className="font-bold text-foreground text-sm mb-4">Flujo de efectivo</h3>
          <div className="space-y-1">
            {[["Ingresos por ventas", "+$84,230", "ingreso"], ["Compras a proveedores", "-$52,300", "egreso"], ["Gastos operativos", "-$8,400", "egreso"], ["Impuestos (IVA)", "-$11,640", "egreso"], ["Flujo neto del periodo", "$11,890", "neto"]].map(([l, v, t], i) => (
              <div key={i} className={`flex items-center justify-between py-3 border-b border-border/30 last:border-0 ${t === "neto" ? "mt-1 border-t-2 border-border/60" : ""}`}>
                <span className="text-sm text-muted-foreground">{l}</span>
                <span className={`text-sm font-bold ${t === "ingreso" ? "text-green-600" : t === "egreso" ? "text-red-500" : "text-primary"}`}>{v}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <BottomSheet isOpen={showExport} onClose={() => setShowExport(false)} title="Exportar reporte">
        <div className="p-4 space-y-3">
          {[{ label: "Descargar PDF", icon: Download }, { label: "Exportar Excel", icon: Download }, { label: "Compartir por correo", icon: Mail }].map(e => (
            <button key={e.label} className="w-full flex items-center gap-4 p-4 bg-muted rounded-xl text-left cursor-pointer hover:bg-border transition-colors min-h-[64px]">
              <e.icon size={20} className="text-primary shrink-0" />
              <span className="text-sm font-semibold text-foreground">{e.label}</span>
            </button>
          ))}
        </div>
      </BottomSheet>
    </div>
  );
}

// ── AI Assistant ────────────────────────────────────────────────────────────
function AIAssistantScreen() {
  const { isMobile } = useBreakpoint();
  const [messages, setMessages] = useState(initAiMessages);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [showInsights, setShowInsights] = useState(false);
  const chatRef = useRef<HTMLDivElement>(null);

  const quickQueries = ["Cuanto vendi hoy?", "Que reabastecer?", "Mas rentables?", "Tendencias?"];

  const sendMessage = (text: string) => {
    if (!text.trim()) return;
    setMessages(prev => [...prev, { role: "user", content: text }]);
    setInput("");
    setLoading(true);
    setTimeout(() => {
      setMessages(prev => [...prev, { role: "assistant", content: "Analizando los datos de tu negocio... Basandome en el historial de ventas e inventario, tu negocio muestra una tendencia positiva. Te gustaria que profundice en algun aspecto especifico?" }]);
      setLoading(false);
    }, 1400);
  };

  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages, loading]);

  const InsightsList = () => (
    <div className="space-y-3 p-4">
      {aiInsights.map((insight, i) => {
        const Icon = insight.icon;
        return (
          <div key={i} className="flex gap-3 p-3 bg-muted rounded-xl">
            <Icon size={16} className={`${insight.color} shrink-0 mt-0.5`} />
            <div><div className="text-sm font-bold text-foreground">{insight.titulo}</div><div className="text-xs text-muted-foreground">{insight.desc}</div></div>
          </div>
        );
      })}
      <div className="bg-foreground rounded-xl p-4">
        <div className="text-xs font-bold text-white/60 mb-3 uppercase tracking-wide">Resumen</div>
        {[["Ventas hoy", "$12,450", "text-secondary"], ["Inventario", "8 productos", "text-white"], ["Stock bajo", "4 alertas", "text-amber-400"], ["Margen", "24.8%", "text-secondary"]].map(([l, v, c]) => (
          <div key={l} className="flex justify-between py-1.5 border-b border-white/8 last:border-0"><span className="text-white/55 text-xs">{l}</span><span className={`text-xs font-bold ${c}`}>{v}</span></div>
        ))}
      </div>
    </div>
  );

  const chatPanel = (
    <div className={`flex flex-col bg-card rounded-2xl border border-border/50 overflow-hidden shadow-sm ${isMobile ? "h-full" : "flex-1"}`}>
      <div className="flex items-center gap-3 px-4 py-3.5 border-b border-border/50 shrink-0">
        <div className="w-9 h-9 bg-foreground rounded-xl flex items-center justify-center shrink-0"><Sparkles size={15} className="text-accent" /></div>
        <div className="flex-1">
          <div className="font-bold text-foreground text-sm">Asistente RetailOS</div>
          <div className="flex items-center gap-1.5"><div className="w-1.5 h-1.5 bg-secondary rounded-full" /><span className="text-xs text-muted-foreground">Conectado a tus datos</span></div>
        </div>
        {isMobile && <button onClick={() => setShowInsights(true)} className="text-xs text-primary font-semibold px-3 py-2 bg-primary/10 rounded-xl cursor-pointer min-h-[36px]">Insights</button>}
        <button className="w-8 h-8 rounded-xl bg-muted flex items-center justify-center cursor-pointer shrink-0"><RefreshCw size={13} className="text-muted-foreground" /></button>
      </div>
      <div ref={chatRef} className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((msg, i) => (
          <div key={i} className={`flex gap-3 ${msg.role === "user" ? "flex-row-reverse" : ""}`}>
            {msg.role === "assistant" && (<div className="w-8 h-8 bg-foreground rounded-xl flex items-center justify-center shrink-0 mt-0.5"><Sparkles size={13} className="text-accent" /></div>)}
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 text-sm leading-relaxed whitespace-pre-line ${msg.role === "user" ? "bg-primary text-white rounded-tr-sm" : "bg-muted text-foreground rounded-tl-sm"}`}>{msg.content}</div>
          </div>
        ))}
        {loading && (
          <div className="flex gap-3">
            <div className="w-8 h-8 bg-foreground rounded-xl flex items-center justify-center shrink-0"><Sparkles size={13} className="text-accent" /></div>
            <div className="bg-muted rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-1.5">
              {[0, 150, 300].map(d => <div key={d} className="w-2 h-2 bg-muted-foreground/50 rounded-full animate-bounce" style={{ animationDelay: `${d}ms` }} />)}
            </div>
          </div>
        )}
      </div>
      <div className="px-4 py-2.5 border-t border-border/30 flex gap-2 overflow-x-auto shrink-0">
        {quickQueries.map(q => (<button key={q} onClick={() => sendMessage(q)} className="shrink-0 px-3 py-2 bg-primary/8 text-primary text-xs rounded-xl font-semibold whitespace-nowrap border border-primary/15 cursor-pointer min-h-[36px]">{q}</button>))}
      </div>
      <div className="px-4 py-3 border-t border-border/50 shrink-0">
        <div className="flex gap-3">
          <input value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === "Enter" && !e.shiftKey && sendMessage(input)}
            placeholder="Pregunta sobre ventas, inventario o tendencias..."
            className="flex-1 px-4 py-3 rounded-xl bg-muted border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 min-h-[48px]" />
          <button onClick={() => sendMessage(input)} disabled={!input.trim() || loading}
            className="w-11 h-11 bg-primary text-white rounded-xl flex items-center justify-center hover:bg-secondary disabled:opacity-40 cursor-pointer shrink-0 min-w-[44px]"><Send size={16} /></button>
        </div>
      </div>
    </div>
  );

  if (isMobile) {
    return (
      <div style={{ height: "calc(100vh - 56px - 64px)" }} className="flex flex-col">
        {chatPanel}
        <BottomSheet isOpen={showInsights} onClose={() => setShowInsights(false)} title="Insights IA"><InsightsList /></BottomSheet>
      </div>
    );
  }

  return (
    <div className="flex gap-4 h-[calc(100vh-112px)] pb-4">
      {chatPanel}
      <div className="w-72 flex flex-col gap-4 shrink-0">
        <div className="bg-card rounded-2xl border border-border/50 shadow-sm overflow-auto flex-1">
          <div className="flex items-center gap-2 p-4 border-b border-border/50"><Sparkles size={15} className="text-primary" /><h3 className="font-bold text-foreground text-sm">Insights IA</h3></div>
          <InsightsList />
        </div>
        <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
          <h3 className="font-bold text-foreground text-sm mb-3">Historial de chats</h3>
          <div className="space-y-1">
            {[{ t: "Analisis junio", time: "Hace 2 horas", active: true }, { t: "Reabastecimiento urgente", time: "Ayer" }, { t: "Rentabilidad categorias", time: "Hace 3 dias" }].map((chat, i) => (
              <button key={i} className={`w-full text-left px-3 py-2.5 rounded-xl cursor-pointer min-h-[48px] transition-colors ${chat.active ? "bg-primary/10 border border-primary/20" : "hover:bg-muted"}`}>
                <div className={`text-sm font-semibold truncate ${chat.active ? "text-primary" : "text-foreground"}`}>{chat.t}</div>
                <div className="text-xs text-muted-foreground">{chat.time}</div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Settings Screen ─────────────────────────────────────────────────────────
function SettingsScreen() {
  const { isMobile } = useBreakpoint();
  const [activeTab, setActiveTab] = useState("negocio");
  const [notifications, setNotifications] = useState([true, true, false, true]);
  const [openSection, setOpenSection] = useState<string | null>("datos");

  const tabs = [
    { id: "negocio", label: "Mi negocio", icon: Building2 },
    { id: "usuarios", label: "Usuarios", icon: Users },
    { id: "pagos", label: "Pagos", icon: CreditCard },
    { id: "ia", label: "Config. IA", icon: Bot },
    { id: "tickets", label: "Tickets", icon: Printer },
  ];

  const formFields = [
    { label: "Nombre del negocio", value: "Abarrotes El Roble", full: false },
    { label: "RFC / Registro fiscal", value: "AERL850312X01", full: false },
    { label: "Direccion completa", value: "Calle Principal 45, Col. Centro, CDMX 06000", full: true },
    { label: "Telefono", value: "55-1234-5678" },
    { label: "Correo electronico", value: "contacto@elroble.mx" },
    { label: "Sitio web", value: "www.elroble.mx" },
  ];

  const NotifToggles = () => (
    <div className="space-y-1">
      {["Alertas de stock bajo", "Resumen diario de ventas", "Alertas de agotados", "Recomendaciones IA"].map((n, i) => (
        <div key={n} className="flex items-center justify-between py-3.5 border-b border-border/30 last:border-0">
          <span className="text-sm font-semibold text-foreground pr-4">{n}</span>
          <button onClick={() => setNotifications(prev => prev.map((v, idx) => idx === i ? !v : v))}
            className={`relative w-11 h-6 rounded-full cursor-pointer transition-colors shrink-0 ${notifications[i] ? "bg-primary" : "bg-muted"}`}>
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-sm transition-all ${notifications[i] ? "left-6" : "left-1"}`} />
          </button>
        </div>
      ))}
    </div>
  );

  if (isMobile) {
    const sections = [
      {
        id: "datos", title: "Datos del negocio", Icon: Building2, content: (
          <div className="space-y-4">
            {formFields.map(f => (
              <div key={f.label}>
                <label className="block text-xs font-bold text-muted-foreground mb-1.5">{f.label}</label>
                <input defaultValue={f.value} className="w-full px-3 py-3 rounded-xl border border-border bg-muted text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 min-h-[48px]" />
              </div>
            ))}
            <Btn variant="primary" className="w-full min-h-[52px]">Guardar cambios</Btn>
          </div>
        )
      },
      { id: "notif", title: "Notificaciones", Icon: Bell, content: <NotifToggles /> },
      {
        id: "integ", title: "Integraciones", Icon: Zap, content: (
          <div className="space-y-3">
            {[{ name: "WhatsApp Business", connected: true }, { name: "Stripe Terminal", connected: false }, { name: "Facturacion SAT", connected: false }].map(int => (
              <div key={int.name} className="flex items-center justify-between p-4 border border-border/50 rounded-xl">
                <span className="text-sm font-semibold text-foreground">{int.name}</span>
                <Btn variant={int.connected ? "secondary" : "primary"} size="sm">{int.connected ? "Conectado" : "Conectar"}</Btn>
              </div>
            ))}
          </div>
        )
      },
    ];

    return (
      <div className="space-y-3 pb-6">
        {sections.map(section => {
          const Icon = section.Icon;
          const isOpen = openSection === section.id;
          return (
            <div key={section.id} className="bg-card rounded-2xl border border-border/50 overflow-hidden shadow-sm">
              <button onClick={() => setOpenSection(isOpen ? null : section.id)} className="w-full flex items-center justify-between px-4 py-4 cursor-pointer min-h-[60px]">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 bg-primary/10 rounded-xl flex items-center justify-center"><Icon size={16} className="text-primary" /></div>
                  <span className="font-semibold text-foreground">{section.title}</span>
                </div>
                <ChevronDown size={16} className={`text-muted-foreground transition-transform ${isOpen ? "rotate-180" : ""}`} />
              </button>
              {isOpen && <div className="px-4 pb-4">{section.content}</div>}
            </div>
          );
        })}
      </div>
    );
  }

  return (
    <div className="flex gap-5 pb-8">
      <div className="w-48 shrink-0">
        <div className="bg-card rounded-2xl border border-border/50 p-2 space-y-0.5 shadow-sm">
          {tabs.map(tab => {
            const Icon = tab.icon;
            return (
              <button key={tab.id} onClick={() => setActiveTab(tab.id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 rounded-xl text-sm cursor-pointer min-h-[44px] transition-all ${activeTab === tab.id ? "bg-primary text-white font-semibold" : "text-muted-foreground hover:bg-muted hover:text-foreground font-medium"}`}>
                <Icon size={15} />{tab.label}
              </button>
            );
          })}
        </div>
      </div>
      <div className="flex-1 space-y-5">
        <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
          <h2 className="text-base font-bold text-foreground mb-5">Datos del negocio</h2>
          <div className="grid grid-cols-2 gap-4">
            {formFields.map(f => (
              <div key={f.label} className={f.full ? "col-span-2" : ""}>
                <label className="block text-xs font-bold text-muted-foreground mb-1.5">{f.label}</label>
                <input defaultValue={f.value} className="w-full px-3 py-2.5 rounded-xl border border-border bg-muted text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-all" />
              </div>
            ))}
          </div>
          <div className="mt-5 flex gap-3"><Btn variant="primary">Guardar cambios</Btn><Btn variant="ghost">Cancelar</Btn></div>
        </div>
        <div className="bg-card rounded-2xl border border-border/50 p-6 shadow-sm">
          <h2 className="text-base font-bold text-foreground mb-5">Notificaciones</h2>
          <NotifToggles />
        </div>
      </div>
    </div>
  );
}

// ── Help Screen ─────────────────────────────────────────────────────────────
function HelpScreen() {
  const { isMobile } = useBreakpoint();
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const faqs = [
    { q: "Como agrego un producto nuevo al inventario?", a: "Ve al modulo de Inventario, haz clic en Agregar producto y completa el formulario con el nombre, SKU, precios y stock inicial." },
    { q: "Como configuro los metodos de pago?", a: "En Configuracion > Pagos puedes activar o desactivar efectivo, transferencia bancaria y terminal bancaria." },
    { q: "Como genero un reporte de ventas en PDF?", a: "Ve al modulo de Reportes, selecciona el periodo y haz clic en el boton PDF en la barra de controles." },
    { q: "Como uso el escaner de codigo de barras?", a: "En el Punto de Venta, haz clic en el boton Escanear. Permite el acceso a la camara cuando se solicite." },
    { q: "El asistente IA hace pedidos automaticamente?", a: "Por ahora analiza y recomienda, pero los pedidos se realizan manualmente. La automatizacion llegara en v3.0." },
  ];

  return (
    <div className="space-y-4 pb-6">
      <div className={`grid gap-3 ${isMobile ? "grid-cols-1" : "grid-cols-3"}`}>
        {[
          { title: "Documentacion", desc: "Guias completas de uso", Icon: BookOpen, bg: "bg-blue-50 border-blue-200", ic: "text-blue-600", ibg: "bg-blue-100" },
          { title: "Soporte en vivo", desc: "Chat con un especialista", Icon: MessageSquare, bg: "bg-green-50 border-green-200", ic: "text-green-600", ibg: "bg-green-100" },
          { title: "Soporte telefonico", desc: "Lunes a Viernes 9am-7pm", Icon: Phone, bg: "bg-primary/5 border-primary/20", ic: "text-primary", ibg: "bg-primary/10" },
        ].map(s => (
          <div key={s.title} className={`border rounded-2xl p-5 cursor-pointer hover:shadow-md transition-shadow min-h-[100px] ${s.bg}`}>
            <div className={`w-11 h-11 rounded-xl ${s.ibg} flex items-center justify-center mb-3`}><s.Icon size={21} className={s.ic} /></div>
            <div className="font-bold text-foreground">{s.title}</div>
            <div className="text-muted-foreground text-sm mt-1">{s.desc}</div>
            <div className={`flex items-center gap-1 text-xs font-bold mt-3 ${s.ic}`}>Ver mas <ChevronRight size={13} /></div>
          </div>
        ))}
      </div>

      <div className="bg-card rounded-2xl border border-border/50 p-4 shadow-sm">
        <h2 className="text-base font-bold text-foreground mb-4 flex items-center gap-2"><LifeBuoy size={18} className="text-primary" />Preguntas frecuentes</h2>
        <div className="space-y-2">
          {faqs.map((faq, i) => (
            <div key={i} className="border border-border/50 rounded-xl overflow-hidden">
              <button className="w-full flex items-center justify-between px-4 py-4 text-left cursor-pointer min-h-[56px] hover:bg-muted/50 transition-colors" onClick={() => setOpenFaq(openFaq === i ? null : i)}>
                <span className="text-sm font-semibold text-foreground pr-4">{faq.q}</span>
                <ChevronDown size={15} className={`text-muted-foreground transition-transform shrink-0 ${openFaq === i ? "rotate-180" : ""}`} />
              </button>
              {openFaq === i && <div className="px-4 pb-4 border-t border-border/30"><p className="text-sm text-muted-foreground leading-relaxed pt-3">{faq.a}</p></div>}
            </div>
          ))}
        </div>
      </div>

      <div className="bg-foreground rounded-2xl p-5 shadow-sm">
        <div className={`flex gap-4 ${isMobile ? "flex-col" : "items-center justify-between"}`}>
          <div><h2 className="text-base font-bold text-white">Necesitas mas ayuda?</h2><p className="text-white/55 text-sm mt-1">Nuestro equipo esta disponible para ayudarte</p></div>
          <div className="flex gap-3">
            <Btn variant="accent" size="md" className="min-h-[48px]"><MessageCircle size={15} />Chat en vivo</Btn>
            <Btn variant="outline" size="md" className="border-white/20 text-white hover:bg-white/10 min-h-[48px]"><Mail size={15} />Email</Btn>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── App ─────────────────────────────────────────────────────────────────────
export default function App() {
  const { isMobile } = useBreakpoint();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeModule, setActiveModule] = useState("dashboard");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  if (!isLoggedIn) return <LoginScreen onLogin={() => setIsLoggedIn(true)} />;

  if (isMobile) {
    return (
      <div className="flex flex-col h-screen bg-background">
        <Header activeModule={activeModule} isMobile onMenuOpen={() => setMobileMenuOpen(true)} />
        <main className="flex-1 overflow-auto px-4 pt-3 pb-0">
          {activeModule === "dashboard" && <DashboardScreen />}
          {activeModule === "pos" && <POSScreen />}
          {activeModule === "inventory" && <InventoryScreen />}
          {activeModule === "reports" && <ReportsScreen />}
          {activeModule === "ai" && <AIAssistantScreen />}
          {activeModule === "settings" && <SettingsScreen />}
          {activeModule === "help" && <HelpScreen />}
        </main>
        <BottomNav activeModule={activeModule} setActiveModule={setActiveModule} />
        <MobileDrawer isOpen={mobileMenuOpen} onClose={() => setMobileMenuOpen(false)} activeModule={activeModule} setActiveModule={setActiveModule} onLogout={() => setIsLoggedIn(false)} />
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <Sidebar activeModule={activeModule} setActiveModule={setActiveModule} onLogout={() => setIsLoggedIn(false)} collapsed={sidebarCollapsed} onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)} />
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        <Header activeModule={activeModule} isMobile={false} onMenuOpen={() => {}} />
        <main className="flex-1 overflow-auto px-5 pt-5">
          {activeModule === "dashboard" && <DashboardScreen />}
          {activeModule === "pos" && <POSScreen />}
          {activeModule === "inventory" && <InventoryScreen />}
          {activeModule === "reports" && <ReportsScreen />}
          {activeModule === "ai" && <AIAssistantScreen />}
          {activeModule === "settings" && <SettingsScreen />}
          {activeModule === "help" && <HelpScreen />}
        </main>
      </div>
    </div>
  );
}
